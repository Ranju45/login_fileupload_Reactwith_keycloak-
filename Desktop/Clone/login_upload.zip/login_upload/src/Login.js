import React, { useState } from 'react';
import { Navigate } from 'react-router-dom';
import './login.css';

const Login = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [message, setMessage] = useState('');
  const [redirectToUpload, setRedirectToUpload] = useState(false);

  const handleLogin = async (event) => {
    event.preventDefault();

    const data = new URLSearchParams();
    data.append('username', username);
    data.append('password', password);
    data.append('client_id', 'bca');
    data.append('client_secret', 'UDmd918S4WYz89ZPAwtXBfCkgbDm86vE');
    data.append('grant_type', 'password');
    data.append('scope', 'openid');

    try {
      const response = await fetch('/auth-api', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: data.toString(),
      });

      const responseData = await response.json();

      if (!response.ok) {
        throw new Error(responseData.error_description || 'Login failed');
      }

      const token = responseData.access_token;
     // console.log(token);
      
      // Store the token in localStorage
      localStorage.setItem('authToken', token);

      setMessage('Login successful!');
      setRedirectToUpload(true);
    } catch (error) {
      console.error(error.message);
      setMessage('Login failed. Please check your credentials and try again.');
    }
  };

  if (redirectToUpload) {
    return <Navigate to="/fileupload" />;
  }

  return (
    <div>
      <h1>Login</h1>
      <form onSubmit={handleLogin}>
        <div>
          <label>Username:</label>
          <input
            type="text"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
          />
        </div>
        <div>
          <label>Password:</label>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </div>
        <button type="submit">Login</button>
      </form>
      {message && <p>{message}</p>}
    </div>
  );
};

export default Login;

