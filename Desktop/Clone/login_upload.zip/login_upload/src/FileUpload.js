
import React, { useState, useEffect } from 'react';
import './styles.css';
const FileUpload = () => {
  const [file, setFile] = useState(null);
  const [message, setMessage] = useState('');

  const handleFileChange = (event) => {
    setFile(event.target.files[0]);
  };

  const handleUpload = async (event) => {
    event.preventDefault();

    if (!file) {
      setMessage('Please select a file to upload.');
      return;
    }

    const token = localStorage.getItem('authToken');
    if (!token) {
      setMessage('You need to log in first.');
      return;
    }

    const formData = new FormData();
    formData.append('file', file);

    try {
      const response = await fetch('/uploadfile', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
        },
        body: formData,
      });

      if (!response.ok) {
        throw new Error('File upload failed. Please try again.');
      }

      setMessage('File uploaded successfully!');
    } catch (error) {
      console.error('Error:', error);

      // Check if the error contains a response
      if (error.response) {
        // Check if the response is JSON
        if (error.response.headers.get('content-type')?.includes('multipart/form-data; boundary=<calculated when request is sent>')) {
          // If the response is JSON, parse and log the error message
          const errorData = await error.response.json();
          setMessage(`File upload failed: ${errorData.message || 'Please try again.'}`);
        } else {
          // If the response is not JSON, log a generic error message
          setMessage('File upload failed. Please try again.');
        }
      } else {
        // If the error does not contain a response, log a generic error message
        setMessage('File upload failed. Please try again.');
      }
    }
  };

  useEffect(() => {
    // Fetch data when the component mounts
    fetch('/data')
      .then(response => response.json())
      .then(data => console.log(data))
      .catch(error => console.error(error));
  }, []); // Empty dependency array ensures it only runs once on mount

  return (
    <div>
      <h1>Upload File</h1>
      <form onSubmit={handleUpload}>
        <div>
          <input type="file" onChange={handleFileChange} />
        </div>
        <button type="submit">Upload</button>
      </form>
      {message && <p>{message}</p>}
    </div>
  );
};

export default FileUpload;
