const { createProxyMiddleware } = require('http-proxy-middleware');

module.exports = function(app) {

  // Proxy for the authentication API
  app.use(
    '/auth-api',
    createProxyMiddleware({
      target: 'https://2b21-2409-40f2-2040-c67a-2d8a-3bf3-ffae-45d6.ngrok-free.app/realms/master/protocol/openid-connect/token',
      changeOrigin: true,
      logLevel: 'debug',
      pathRewrite: {
        '^/auth-api': '', // Remove '/auth-api' from the request path
      }
    })
  );

  // Proxy for the file upload API
  app.use(
    '/uploadfile',
    createProxyMiddleware({
      target: 'https://2303-2409-40f2-2b-14ca-158d-c685-e7e-c9ed.ngrok-free.app/push',
      changeOrigin: true,
      pathRewrite: {
        '^/uploadfile': '', // Remove '/auth-api' from the request path
      }
    })
  );
};
